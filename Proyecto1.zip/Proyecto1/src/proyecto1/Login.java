/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 *
 * @author PAZ ZUÑIGA
 */
public class Login  extends JFrame implements ActionListener{
    JButton salir,ingresar;
    JTextField user,pin;
    JLabel et1,et2;
    
    public Login(){
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setUndecorated(true);
        setSize(500,600);
        setLocationRelativeTo(null);
        
        
        ImageIcon fondo= new ImageIcon("imagenes/fondo.jpg");
        JLabel jlFondo=new JLabel(fondo);
        jlFondo.setBounds(0,0,1820,1096);
        
        ImageIcon logo=new ImageIcon("src/img/Log2.png");
        JLabel logoimg=new JLabel(logo);
        logoimg.setBounds(190,40,128,128);
        
        ImageIcon us=new ImageIcon("src/img/usuario.png");
        JLabel jlUser=new JLabel(us);
        jlUser.setBounds(90,220,32,32);
        
        JLabel txtUser=new JLabel("Usuario");
        txtUser.setForeground(Color.ORANGE);
        txtUser.setBounds(130,190,50,20);
        user=new JTextField();
        user.setBounds(130,220,270,40);
        
        ImageIcon imgPin=new ImageIcon("src/img/llave.png");
        JLabel jlPin=new JLabel(imgPin);
        jlPin.setBounds(90,325,32,32);
        
        JLabel txtPin=new JLabel("PIN");
        txtPin.setForeground(Color.RED);
        txtPin.setBounds(130,290,50,20);
        pin=new JTextField();
        pin.setBounds(130,320,270,40);
        
        et1=new JLabel();
        et1.setBounds(410,220,32,32);
        
        et2=new JLabel();
        et2.setBounds(410,325,32,32);
        Color naranja=new Color(102,255,102);
        Color dorado=new Color(255,102,102);
        salir=new JButton("Salir");
        salir.setBounds(140,400,100,50);
        salir.addActionListener(this);
        salir.setBackground(dorado);
        
        ingresar=new JButton("ingresar");
        ingresar.setBounds(280,400,100,50);
        ingresar.addActionListener(this);
        ingresar.setBackground(naranja);
        
        JPanel ventana=new JPanel();
        ventana.setLayout(null);
        ventana.setSize(500,600);
        
        ventana.add(et2);
        ventana.add(et1);
        ventana.add(ingresar);
        ventana.add(salir);
        ventana.add(jlPin);
        ventana.add(jlUser);
        ventana.add(txtPin);
        ventana.add(pin);
        ventana.add(txtUser);
        ventana.add(user);
        ventana.add(logoimg);
        ventana.add(jlFondo);
        
        
        add(ventana);
        setVisible(true);
    
        
        
        
    }
    public void actionPerformed(ActionEvent accion){
        if(accion.getSource()==salir){
            System.exit(0);
            
        }
        if(accion.getSource()==ingresar){
            String userS,pinS;
            userS=user.getText();
            pinS=pin.getText();
            if("Pablo".equals(userS)){
                ImageIcon user1=new ImageIcon("src/img/bien.png");
                et1.setIcon(user1);
                if("2345".equals(pinS)){
                    ImageIcon user2=new ImageIcon("src/img/bien.png");
                    et2.setIcon(user2);
                    et2.setIcon(user2);
                    setVisible(false);
                    JOptionPane.showMessageDialog(null,"Bienvenido usuario","Mensaje",JOptionPane.INFORMATION_MESSAGE);
                     Inicio n=new Inicio();
                     n.menu();
                    
                    
                }else{
                   ImageIcon user2=new ImageIcon("src/img/mal.png");
                   et2.setIcon(user2);
                }
            }else{
                   
                 ImageIcon user1=new ImageIcon("src/img/mal.png");
                 et1.setIcon(user1);
                 
                 if("1234".equals(pinS)){
                   ImageIcon user2=new ImageIcon("src/img/bien.png");
                   et2.setIcon(user2); 
                }else{
                   ImageIcon user2=new ImageIcon("src/img/mal.png");
                   et2.setIcon(user2);
                }
            }
            
        }
        
    }
    
}
