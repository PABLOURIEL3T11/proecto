/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
/**
 *
 * @author PAZ ZUÑIGA
 */
public class Paquetes extends JFrame implements ActionListener{
   Color colorfra;JButton b6,b7,b8,b9,b10,b11,atras,salir;
    JFrame retiro;JLabel l4,eti; JPanel p2; ImageIcon img;
    Double saldo=7000.00,monto,reti ;
    
    JFrame jfTicket;
    JLabel logoServ,nomServ; JTextArea areaTicket; JButton continuar,terminar;
    
    public void funcionesDep(){
       
        setUndecorated(true);
        setSize(700,650);
        setLocationRelativeTo(null);
        
        colorfra=new Color(179,230,255);
        
        ImageIcon fondo=new ImageIcon("src/img/agua.jpg");
        JLabel fn=new JLabel(fondo);
        fn.setBounds(0,0,1100,600);
       
        eti=new JLabel("CHIPS DE TELEFONIA");
        eti.setFont(new Font("Serif",Font.BOLD, 30));
        eti.setBounds(200,50,400,30);
        

        
          b6=new JButton (" MOVISTAR $100");
          b6.setBounds(50,200,200,70);
          b6.addActionListener(this);      
          b7=new JButton("TELCEL $200");
          b7.setBounds(50,300,200,70);
          b7.addActionListener(this);
         
          b8=new JButton("PILLOFON $300");
          b8.setBounds(450,200,200,70);
          b8.addActionListener(this);
         
          b9=new JButton("AT&T $210");
          b9.setBounds(450,300,200,70); 
          b9.addActionListener(this);
        
          atras=new JButton(new ImageIcon("icono.jpg"));
          atras.setBounds(30,10,64,64);
          atras.addActionListener(this);
          
          
          
           
           
          
        p2=new JPanel();
        p2.setLayout(null);
        p2.setBounds(0,0,600,400);
        p2.setBackground(colorfra);
        p2.add(eti);
        p2.add(b6);
        p2.add(b7);
        p2.add(b8);
        p2.add(b9);
        p2.add(atras);
        p2.add(fn);
       
        
        add(p2);
        setVisible(true);
        
        
        
    }
    
    
    
    public void impTicket(){
        jfTicket = new JFrame();
        jfTicket.setUndecorated(true);
        jfTicket.setSize(400,600);
        jfTicket.setLocationRelativeTo(null);
        
        ImageIcon img=new ImageIcon("Iconcelular.png");
        logoServ= new JLabel(img);
        logoServ.setBounds(50,45,50,50);
        
        
        nomServ=new JLabel("CENTRO DE RECARGAS");
        nomServ.setBounds(120,50,200,30);
        
        areaTicket= new JTextArea();
        areaTicket.setBounds(50,100,350,400);
        areaTicket.setEditable(false);
        areaTicket.setText("Tienda:Telefonica TESOEM\n\n"
                +"=========================\n\n"
                +"\nFolio:5466\n"
                +"\nMatricula 217010003\n"
                +"\n\n"
                +"===================================\n"
                +"Tu compra se realizo en el CENTRO CACTUS JACK\n"
                +"Te antendio: PABLO URIEL PAZ Y JONATHAN MORA.\n\n"
                +"Muchas gracias por tu compra\n\n"
                +"Tel:5561049375\n"
                +"====================================\n");
        continuar= new JButton("Realizar otra operación");
        continuar.setBounds(50,460,300,30);
        continuar.setBackground(Color.ORANGE);
        continuar.addActionListener(this);
        
        terminar= new JButton("Terminar y salir");
        terminar.setBounds(50,520,300,30);
        terminar.setBackground(Color.ORANGE);
        terminar.addActionListener(this);
        
        JPanel PTicket= new JPanel();
        PTicket.setLayout(null);
        PTicket.setBounds(0,0,500,300);
        PTicket.setBackground(Color.ORANGE);
        
        PTicket.add(terminar);
        PTicket.add(continuar);
        PTicket.add(areaTicket);
        PTicket.add(nomServ);
        PTicket.add(logoServ);
        
        jfTicket.add(PTicket);
        jfTicket.setVisible(true);
    }
    
    
    
    
   
         
    public void actionPerformed(ActionEvent presiona){

        if(presiona.getSource()==b6){
            
           
            saldo=saldo-100;
            monto=100.00;
            JOptionPane.showMessageDialog(null,"Compra Exitosa tu saldo es $"+saldo,"Saldo",JOptionPane.INFORMATION_MESSAGE);
             this.setVisible(false);
            impTicket();
                
        }
        
        if(presiona.getSource()==b7){
               
                saldo=saldo-200;
            monto=200.00;
            JOptionPane.showMessageDialog(null,"Compra  Exitosa tu saldo es $"+saldo,"Saldo",JOptionPane.INFORMATION_MESSAGE);
             this.setVisible(false);
            impTicket();
             
        }
        
        if(presiona.getSource()==b8){
           
                saldo=saldo-300;
            monto=300.00;
            JOptionPane.showMessageDialog(null,"Compra Exitosa tu saldo es $"+saldo,"Saldo",JOptionPane.INFORMATION_MESSAGE);
             this.setVisible(false);
             impTicket();
           
        }
        
        if(presiona.getSource()==b9){
                   
             saldo=saldo-210;
            monto=210.00;
            JOptionPane.showMessageDialog(null,"Deposito Exitoso tu saldo es $"+saldo,"Saldo",JOptionPane.INFORMATION_MESSAGE);
             this.setVisible(false);
             impTicket();
       
           
             
        }
        
        if(presiona.getSource()==atras){
            this.setVisible(false);
            Inicio letsGo=new Inicio();
            letsGo.menu();
        }
        
        if(presiona.getSource()==continuar){
             jfTicket.setVisible(false);
            Inicio ven=new Inicio();
            ven.menu();
        }
        
        if(presiona.getSource()==terminar){
            jfTicket.setVisible(false);
            Login ven=new Login();
            
        }
    }
    
}
