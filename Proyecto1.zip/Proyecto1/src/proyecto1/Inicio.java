/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
//import javax.swing.JTextField;

/**
 *
 * @author PAZ ZUÑIGA
 */
public class Inicio extends JFrame implements ActionListener {
 JPanel p1,p2; 
    JButton b1,b2,b3,b4,b5; 
    JLabel l1,e2,l3,l4,eti; 
    ImageIcon img2; 
    Color colorfra;
    Double saldo=5000.50;
     public void menu(){
    setDefaultCloseOperation(EXIT_ON_CLOSE);
       setUndecorated(true);
       setSize(1100,600);
       setLocationRelativeTo(null);
       
        ImageIcon img=new ImageIcon("fondo.jpg");
        JLabel imgUno=new JLabel(img);
        imgUno.setBounds(0,0,1100,600);
      
        img2=new ImageIcon("celular.png");
        e2=new JLabel(img2); 
        e2.setBounds(450,15,200,200);
        
        b1=new JButton(new ImageIcon("SALD.jpg"));
        b1.setBounds(100,210,280,150);
        b1.addActionListener(this);
       
       
        
        
       
        b3=new JButton(new ImageIcon("chip.png"));
        b3.setBounds(800,300,250,90);
        b3.addActionListener(this);
       
        b4=new JButton(new ImageIcon("recarga.png"));
        b4.setBounds(700,400,350,70);
        b4.addActionListener(this);
       
        b5=new JButton(new ImageIcon("salir.jpg"));
        b5.setBounds(800,10,250,70);
        b5.addActionListener(this);
        
        
        
      
        
       p1=new JPanel();
       p1.setLayout(null);
       p1.add(e2);
      
       p1.add(b1);
       p1.add(b3);
       p1.add(b4);
       p1.add(b5);
       
       p1.add(imgUno);
      
       
       
       add(p1);
       setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent accion){
        if(accion.getSource()==b1){
           JOptionPane.showMessageDialog(null,"Tu saldo es $"+saldo,"Saldo",JOptionPane.INFORMATION_MESSAGE);
            
      
           
       
               
        }
        
        if(accion.getSource()==b3){
            this.setVisible(false);
            Paquetes corre=new Paquetes();
            corre.funcionesDep();
            
        }
        
        if(accion.getSource()==b4){
            this.setVisible(false);
            servicios llamar= new servicios();
        }
        
       if(accion.getSource()==b5){
           this.setVisible(false);
          Login ven=new Login();
          System.exit(0);
        }
        
    }
    }
