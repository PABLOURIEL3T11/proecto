/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author PAZ ZUÑIGA
 */
public class servicios extends JFrame implements ActionListener {
    JButton regresar,telcel,movistar,atyt,pillofon,pagar,cancelar,continuar,terminar;
    JLabel nomServ,logoServ,nomTarjeta,nomMonto;
    ImageIcon img;
    Color fondoServ;
    JTextField tarjeta,monto;
    JFrame jfPago,jfTicket;
    JTextArea areaTicket;
    String tarje;
    double saldo=7000.00,montoServicio;
    public servicios(){
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setUndecorated(true);
        setSize(1100,600);
        setLocationRelativeTo(null);
        ImageIcon fondo=new ImageIcon("src/img/fondo2.jpg");
        JLabel fn=new JLabel(fondo);
        fn.setBounds(0,0,1065,600);
        regresar=new JButton(new ImageIcon("src/img/icono.jpg"));
        regresar.setBounds(20,20,64,64);
        regresar.addActionListener(this);
        
        JLabel mensajeTit=new JLabel(new ImageIcon("src/img/telfonica.png"));
        mensajeTit.setBounds(70,100,500,52);
        
        telcel=new JButton(new ImageIcon("src/img/serv_telcel.jpg"));
        telcel.setBounds(50,200,250,100);
        telcel.addActionListener(this);
        
        movistar=new JButton(new ImageIcon("src/img/serv_movistar.png"));
        movistar.setBounds(50,400,250,100);
        movistar.addActionListener(this);
        
        atyt=new JButton(new ImageIcon("src/img/serv_AT&T.jpg"));
        atyt.setBounds(800,200,250,100);
        atyt.addActionListener(this);
        
        pillofon=new JButton(new ImageIcon("src/img/pillofon.png"));
        pillofon.setBounds(800,400,250,100);
        pillofon.addActionListener(this);
        
        JPanel ventana=new JPanel();
        ventana.setBounds(0,0,1100,600);
        ventana.setLayout(null);
        
        ventana.add(mensajeTit);
        ventana.add(regresar);
        ventana.add(telcel);
        ventana.add(movistar);
        ventana.add(atyt);
        ventana.add(pillofon);
        
        ventana.add(fn);
        add(ventana);
        setVisible(true);
        
    }
    public void vtnPago(){
        jfPago= new JFrame();
        jfPago.setUndecorated(true);
        jfPago.setSize(600,400);
        jfPago.setLocationRelativeTo(null);
   
        logoServ= new JLabel();
        logoServ.setBounds(50,50,50,30);
        
        nomServ=new JLabel();
        nomServ.setBounds(150,55,200,30);
        
        nomTarjeta= new JLabel("Número de Telefono");
        nomTarjeta.setBounds(50,120,150,40);
        tarjeta=new JTextField();
        tarjeta.setBounds(50,170,200,40);
     
        nomMonto= new JLabel("MONTO A DEPOSITAR ");
        nomMonto.setBounds(300,120,150,40);
        monto=new JTextField();
        monto.setBounds(300,170,200,40);
        
        pagar=new JButton("Pagar");
        pagar.setBounds(320,280,100,40);
        pagar.addActionListener(this);
        
        cancelar=new JButton("Cancelar");
        cancelar.setBounds(120,280,100,40);
        cancelar.addActionListener(this);
        
        JPanel vPago= new JPanel();
        vPago.setLayout(null);
        vPago.setBounds(0,0,500,300);
        vPago.setBackground(fondoServ);
        
        vPago.add(nomServ);
        vPago.add(logoServ);
        vPago.add(tarjeta);
        vPago.add(nomTarjeta);
        vPago.add(nomMonto);
        vPago.add(monto);
        vPago.add(pagar);
        vPago.add(cancelar);
        
        jfPago.add(vPago);
        jfPago.setVisible(true);
           
    }
    public void impTicket(){
        jfTicket=new JFrame();
        jfTicket.setUndecorated(true);
        jfTicket.setSize(400,600);
        jfTicket.setLocationRelativeTo(null);
        
        logoServ=new JLabel();
        logoServ.setBounds(50,50,30,30);
        logoServ.setIcon(img);
        
        nomServ=new JLabel("CENTRO DE RECARGAS");
        nomServ.setBounds(140,100,50,100);
        
        areaTicket=new JTextArea();
        areaTicket.setBounds(50,100,350,400);
        areaTicket.setEditable(false);
        areaTicket.setText("Tienda:Telcel TESOEM\n\n"
                +"=========================\n\n"
                +"Numero de tarjeta:"+tarje
                +"\nFolio:5466\n"
                +"\n\tMonto:$"+montoServicio
                +"\n\n"
                +"===================================\n"
                +"Tu recarga se realizo en el CENTRO CACTUS JACK\n"
                +"Te antendio: PABLO URIEL PAZ Y JONATHAN MORA.\n\n"
                +"Muchas gracias por tu compra\n\n"
                +"Tel:5561049375\n"
                +"====================================\n");
        continuar=new JButton("Realizar otra operacion");
        continuar.setBounds(50,460,300,30);
        continuar.setBackground(Color.WHITE);
        continuar.addActionListener(this);
        terminar=new JButton("SERVICIO TERMINADO DESEO SALIR");
        terminar.setBounds(50,520,300,30);
        terminar.setBackground(Color.RED);
        terminar.addActionListener(this);
        
        JPanel PTicket=new JPanel();
        PTicket.setLayout(null);
        
        PTicket.setBounds(0,0,500,300);
        PTicket.setBackground(Color.WHITE);
        
        PTicket.add(terminar);
        PTicket.add(continuar);
        PTicket.add(areaTicket);
        PTicket.add(nomServ);
        PTicket.add(logoServ);
        
        jfTicket.add(PTicket);
        jfTicket.setVisible(true);
        
              
        
        
        
    }
    public void actionPerformed(ActionEvent accion){
        if(accion.getSource()==regresar){
            this.setVisible(false);
            Inicio inicio= new Inicio();
            inicio.menu();
        }
        
        if(accion.getSource()==telcel){
            this.setVisible(false);
            fondoServ=new Color(204, 255, 204);
            vtnPago();
            img= new ImageIcon("src/img/icon_telcel.png");
            logoServ.setIcon(img);
            nomServ.setText("RECARGA DE TELCEL"); 
        }
        if(accion.getSource()==movistar){
            this.setVisible(false);
            fondoServ=new Color(179, 230, 255);
            vtnPago();
            img= new ImageIcon("src/img/icon_movistar.jpg");
            logoServ.setIcon(img);
            nomServ.setText("RECARGA DE MOVISTAR"); 
        }
        if(accion.getSource()==atyt){
            this.setVisible(false);
            fondoServ=new Color(102, 179, 255);
            vtnPago();
            img= new ImageIcon("src/img/icon_at&t.jpg");
            logoServ.setIcon(img);
            nomServ.setText("RECARGA DE AT&T"); 
        }
        if(accion.getSource()==pillofon){
            this.setVisible(false);
            fondoServ=new Color(255, 179, 128);
            vtnPago();
            img= new ImageIcon("src/img/icon_pillofon.png");
            logoServ.setIcon(img);
            nomServ.setText("RECARGA DE PILLOFON"); 
        }
        if(accion.getSource()==cancelar){
            jfPago.setVisible(false);
            JOptionPane.showMessageDialog(null,"Pago Cancelado ","", JOptionPane.ERROR_MESSAGE);
            
            Inicio ven=new Inicio();
            ven.menu();
        }
        if(accion.getSource()==pagar){
          
            tarje=nomTarjeta.getText();
            montoServicio=Double.valueOf(monto.getText());
            
            if(!"".equals(tarjeta.getText()) || !"".equals(monto.getText())){
                if(saldo>montoServicio){
                        saldo=saldo-montoServicio;
                        tarjeta.setText("");
                        monto.setText("");
                        JOptionPane.showMessageDialog(null,"Servicio pagado exitosamente ","Exitoso ", JOptionPane.INFORMATION_MESSAGE);
                        jfPago.setVisible(false);
                        impTicket();

                }else{
                    JOptionPane.showMessageDialog(null,"El saldo es insuficiente "+saldo,"", JOptionPane.ERROR_MESSAGE);
                }
                
            }else{
                JOptionPane.showMessageDialog(null,"Campos Vacios ","", JOptionPane.ERROR_MESSAGE);
            }
                        
        }
        if(accion.getSource()==continuar){
            jfTicket.setVisible(false);
            Inicio ven=new Inicio();
            ven.menu();
        }
        if(accion.getSource()==terminar){
            jfTicket.setVisible(false);
            JOptionPane.showMessageDialog(null,"Gracias por usar el servicio","", JOptionPane.PLAIN_MESSAGE);
            Login ingresar= new Login();
        }
     
        }
       
    }
    

